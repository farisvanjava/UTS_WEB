<script >
import {ref} from 'vue';

export default{
  setup(){
    const newtodoo = ref('');
    const todos = ref([]);
    function addnewTodoo(){
      todos.value.push({
        id: Date.now(),
        done: false,
        content: newtodoo.value,
      });
      newtodoo = '';
      }
    function toggleDone(todo){
      todo.done = !todo.done;
      }
    // menghapus todoo list
    function Removetodoo(index){
      todos.value.splice(index, 1);
      }

    // menandai semua list
    function markAllDone(){
      todos.value.forEach((todo) => todo.done = true);
      }

      
    return{
    todos,
    newtodoo,
    toggleDone,
    addnewTodoo,
    Removetodoo,
    markAllDone,
    };
  }
}
</script>
<template>
<h1> vue 3 Todoo app</h1>
<form @submit.prevent="addnewTodoo">
  <label >new todoo</label>
  <!-- tempat meng-input nama list -->
  <input v-model="newtodoo" name="newtodoo">
  <button>add new todoo</button>
</form>
<!--Tempat button nark all done -->
  <button @click="markAllDone">Mark All Done</button>
  <ul>
  <li v-for="(todo, index) in todos" :key="todo.id" class="todo">
  <h3 :class="{done: todo.done}" @click="toggleDone(todo)">{{todo.content}}</h3>

<!--Tempat button remove -->
  <button @click="Removetodoo(index)"> Remove Todoo</button>
  </li>
  </ul>

</template>

<style>

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #1681ec;
  margin-top: 60px;
}

.todo{
  cursor: pointer;
}
.done {
  text-decoration: line-through;
}
</style>
